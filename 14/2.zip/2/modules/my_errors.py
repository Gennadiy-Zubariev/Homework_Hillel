class MyError(Exception):
    pass